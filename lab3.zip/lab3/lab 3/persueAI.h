#pragma once
class persueAI
{
public:
	persueAI();
	~persueAI();
};

