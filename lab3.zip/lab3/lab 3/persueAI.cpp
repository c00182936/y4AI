#include "persueAI.h"



persueAI::persueAI()
{
}


persueAI::~persueAI()
{
}
