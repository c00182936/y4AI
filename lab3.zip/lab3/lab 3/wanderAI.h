#pragma once
class wanderAI
{
public:
	wanderAI();
	~wanderAI();
};

