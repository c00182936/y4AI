#include "wanderAI.h"



wanderAI::wanderAI()
{
}


wanderAI::~wanderAI()
{
}
