Black thing=whale, when it collides with a fish, the fish will be eaten. there's a big collision radius around it, a magic number, but it's the only way i could get it working properly.

grey thing=fish, they swarm and avoid the whale

white things= birbs that try to eat the fish

i reccomend running it in release mode as the way i ended up writing the birds is very slow. there's also a memory leak somewhere, i think i know where it is, but i haven't been able to fix it